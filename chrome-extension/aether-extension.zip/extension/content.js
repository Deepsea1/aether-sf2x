// Aether — The Truth Layer for AI
// Chrome Extension: Content Script (Manifest V3)
// Injects a "Verify with Aether" button next to AI chat responses

(function() {
  'use strict';

  const AETHER_API = 'https://aether.sf2x.com/api/functions/verifyResponse';
  const AETHER_COLOR = '#6366f1';

  // Supported AI chat sites
  const SUPPORTED_SITES = [
    'chat.openai.com',
    'chatgpt.com',
    'claude.ai',
    'gemini.google.com',
    'copilot.microsoft.com',
    'www.perplexity.ai',
    'poe.com',
    'character.ai'
  ];

  function isSupportedSite() {
    return SUPPORTED_SITES.some(s => window.location.hostname.includes(s));
  }

  if (!isSupportedSite()) return;

  // Detect AI response containers on each supported site
  function getResponseSelectors() {
    const host = window.location.hostname;
    if (host.includes('chatgpt') || host.includes('openai')) {
      return ['[data-message-author-role="assistant"]', '.markdown'];
    }
    if (host.includes('claude')) {
      return ['[data-testid="assistant-message"]', '.font-claude-message'];
    }
    if (host.includes('gemini')) {
      return ['.response-container', 'model-response'];
    }
    if (host.includes('copilot')) {
      return ['.cib-serp-main', '.ac-container'];
    }
    return ['.message', '[data-role="assistant"]', 'article'];
  }

  function extractResponseText(container) {
    // Get all text content, preserving structure
    const clone = container.cloneNode(true);
    // Remove buttons, inputs, etc.
    clone.querySelectorAll('button, input, script, style, .aether-verify-btn').forEach(el => el.remove());
    return clone.textContent.trim().replace(/\s+/g, ' ').slice(0, 5000);
  }

  function createVerifyButton(container, responseText) {
    // Don't double-inject
    if (container.querySelector('.aether-verify-btn')) return;

    const btn = document.createElement('button');
    btn.className = 'aether-verify-btn';
    btn.innerHTML = '✓ Verify with Aether';
    btn.style.cssText = `
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 4px 12px;
      margin-top: 8px;
      font-size: 12px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-weight: 600;
      color: ${AETHER_COLOR};
      background: transparent;
      border: 1px solid ${AETHER_COLOR};
      border-radius: 16px;
      cursor: pointer;
      transition: all 0.2s;
      opacity: 0.7;
    `;

    btn.addEventListener('mouseenter', () => {
      btn.style.opacity = '1';
      btn.style.background = `${AETHER_COLOR}10`;
    });

    btn.addEventListener('mouseleave', () => {
      if (!btn.classList.contains('aether-verified')) {
        btn.style.opacity = '0.7';
        btn.style.background = 'transparent';
      }
    });

    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();

      btn.innerHTML = '⟳ Tribunal running...';
      btn.style.opacity = '1';
      btn.style.cursor = 'wait';

      try {
        // Get API key from extension storage
        const { aetherApiKey } = await chrome.storage.sync.get('aetherApiKey');

        const response = await fetch(AETHER_API, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(aetherApiKey ? { 'x-api-key': aetherApiKey } : {})
          },
          body: JSON.stringify({
            text: responseText,
            source: window.location.hostname
          })
        });

        const result = await response.json();
        showVerdictCard(container, result);
        updateButton(btn, result);
      } catch (err) {
        btn.innerHTML = '⚠ Verify failed';
        btn.style.borderColor = '#ef4444';
        btn.style.color = '#ef4444';
        setTimeout(() => {
          btn.innerHTML = '✓ Verify with Aether';
          btn.style.borderColor = AETHER_COLOR;
          btn.style.color = AETHER_COLOR;
          btn.style.opacity = '0.7';
        }, 3000);
      }
    });

    container.appendChild(btn);
  }

  function updateButton(btn, result) {
    const score = result.trust_score || 0;
    const verdict = result.verdict || 'unknown';
    btn.classList.add('aether-verified');

    let color, label;
    if (score >= 75) {
      color = '#22c55e';
      label = `✓ Verified ${score}/100`;
    } else if (score >= 50) {
      color = '#eab308';
      label = `⚠ Contested ${score}/100`;
    } else {
      color = '#ef4444';
      label = `✗ Rejected ${score}/100`;
    }

    btn.innerHTML = label;
    btn.style.borderColor = color;
    btn.style.color = color;
    btn.style.opacity = '1';
    btn.style.background = `${color}10`;
  }

  function showVerdictCard(container, result) {
    // Remove existing card
    const existing = container.querySelector('.aether-verdict-card');
    if (existing) existing.remove();

    const score = result.trust_score || 0;
    const verdict = result.verdict || 'unknown';
    const corrections = result.corrections || [];

    let color = score >= 75 ? '#22c55e' : score >= 50 ? '#eab308' : '#ef4444';
    let verdictLabel = score >= 75 ? 'Verified' : score >= 50 ? 'Contested' : 'Rejected';

    const card = document.createElement('div');
    card.className = 'aether-verdict-card';
    card.style.cssText = `
      margin-top: 8px;
      padding: 12px 16px;
      border: 1px solid ${color};
      border-radius: 8px;
      background: ${color}08;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 13px;
      max-width: 500px;
    `;

    let correctionsHTML = '';
    if (corrections.length > 0) {
      correctionsHTML = `
        <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid ${color}30;">
          <div style="font-weight: 600; color: ${color}; margin-bottom: 4px;">Issues found:</div>
          <ul style="margin: 0; padding-left: 20px; color: #475569;">
            ${corrections.map(c => `<li style="margin-bottom: 4px;">${c}</li>`).join('')}
          </ul>
        </div>
      `;
    }

    card.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
        <span style="font-size: 18px; font-weight: 700; color: ${color};">${score}/100</span>
        <span style="font-weight: 600; color: ${color};">${verdictLabel}</span>
        <span style="color: #94a3b8; font-size: 11px; margin-left: auto;">Aether Tribunal</span>
      </div>
      <div style="color: #64748b; font-size: 12px;">
        Verified by 3-model tribunal (proposer → critic → verifier)
      </div>
      ${correctionsHTML}
      <div style="margin-top: 8px; font-size: 11px; color: #94a3b8;">
        ${result.tribunal_url ? `<a href="${result.tribunal_url}" target="_blank" style="color: ${AETHER_COLOR}; text-decoration: none;">View full tribunal debate →</a>` : 'Powered by Aether — The Truth Layer for AI'}
      </div>
    `;

    container.appendChild(card);
  }

  // Observe DOM for new AI responses (chat interfaces are dynamic)
  function scanForResponses() {
    const selectors = getResponseSelectors();
    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      elements.forEach(el => {
        const text = extractResponseText(el);
        if (text.length > 50) { // Only inject for substantial responses
          createVerifyButton(el, text);
        }
      });
    });
  }

  // Initial scan
  setTimeout(scanForResponses, 2000);

  // Watch for new messages being added
  const observer = new MutationObserver((mutations) => {
    let shouldScan = false;
    mutations.forEach(mutation => {
      if (mutation.addedNodes.length > 0) shouldScan = true;
    });
    if (shouldScan) {
      clearTimeout(window.__aetherScanTimeout);
      window.__aetherScanTimeout = setTimeout(scanForResponses, 1000);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  console.log('%c✓ Aether — Truth Layer for AI', `color: ${AETHER_COLOR}; font-weight: bold;`);
  console.log('Verify buttons injected. Click ✓ Verify on any AI response to run the tribunal.');
})();
