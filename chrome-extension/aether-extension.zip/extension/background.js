// Aether Extension — Background Service Worker
// Handles API calls and message passing

chrome.runtime.onInstalled.addListener(() => {
  console.log('Aether — Truth Layer for AI installed');
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'VERIFY') {
    verifyResponse(request.text, request.source)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // async response
  }
});

async function verifyResponse(text, source) {
  const { aetherApiKey } = await chrome.storage.sync.get('aetherApiKey');
  const API = 'https://api.base44.com/api/apps/6a6babb38b48187e5d4799c4/functions/verifyResponse';

  const response = await fetch(API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(aetherApiKey ? { 'Authorization': `Bearer ${aetherApiKey}` } : {})
    },
    body: JSON.stringify({ text, source, domain: 'verification' })
  });

  if (!response.ok) throw new Error(`API returned ${response.status}`);
  return response.json();
}
